/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this soft ware, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "fatfs.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "fatfs_sd.h"
#include "string.h"
#include "stdio.h"
#include "stdarg.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
ADC_HandleTypeDef hadc1;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi2;

UART_HandleTypeDef huart3;

/* USER CODE BEGIN PV */
uint32_t AD_RES[10];
RTC_TimeTypeDef sTime ;
RTC_DateTypeDef DateToUpdate;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_ADC1_Init(void);
static void MX_SPI2_Init(void);
static void MX_RTC_Init(void);
/* USER CODE BEGIN PFP */
void myprintf(const char* fmt,...);
void uintToFloat(float* write_to, uint8_t* write_from, size_t numBytes );
void setDateTime(uint8_t* Rx_time, size_t numBytes);
void strToInt(uint32_t* waitTime,uint8_t* Rx_data_delay, size_t numBytes);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void ADC_Select_CH0(void)
{
	  ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_0;
	  sConfig.Rank = ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH1(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
	  /** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_1;
	  sConfig.Rank = ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH2(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_2;
	  sConfig.Rank = ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH3(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_3;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH4(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	sConfig.Channel = ADC_CHANNEL_4;
	sConfig.Rank =  ADC_REGULAR_RANK_1;;
	sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler();
	}
}

void ADC_Select_CH5(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_5;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH6(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_6;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH7(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_7;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH8(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_8;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}

void ADC_Select_CH9(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};
/** Configure Regular Channel*/
	  sConfig.Channel = ADC_CHANNEL_9;
	  sConfig.Rank =  ADC_REGULAR_RANK_1;;
	  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
		  Error_Handler();
	  }
}
void myprintf(const char* fmt,...)
{
	static char buffer[256];
	va_list args;
	va_start(args, fmt);
	vsnprintf(buffer, sizeof(buffer), fmt, args);
	va_end(args);

	int len = strlen(buffer);
	HAL_UART_Transmit(&huart3, (uint8_t*)buffer, len, -1);
}

void uintToFloat(float* wto, uint8_t* rfrm, size_t numBytes)
{
	int i;
	*wto = 0;
	for(i=0;i < numBytes;i++)
	{
		if((rfrm[i] >= 48) && (rfrm[i] <= 57) )
		{
			*wto = *wto + (rfrm[i]-48)*pow(10,(numBytes-i-1));
		}
		else
		{
			myprintf("Wrong input try again!\r\n");
		}
	}
}

void setDateTime(uint8_t* Rx_time, size_t numBytes)
{
//	 RTC_TimeTypeDef sTime = {0};
//	 RTC_DateTypeDef DateToUpdate = {0};
//
//	 hrtc.Instance = RTC;
//	 hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
//	 hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
//	 if (HAL_RTC_Init(&hrtc) != HAL_OK)
//	 {
//		 Error_Handler();
//	 }

	 sTime.Hours = (Rx_time[9]-48)*16 + (Rx_time[10]-48);
	 sTime.Minutes = (Rx_time[12]-48)*16 + (Rx_time[13]-48);
	 sTime.Seconds = 0x0;

	 if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
	 {
		 Error_Handler();
	 }
	 DateToUpdate.WeekDay = RTC_WEEKDAY_MONDAY;
	 DateToUpdate.Date = (Rx_time[0]-48)*16 + (Rx_time[1]-48);
	 DateToUpdate.Month = (Rx_time[3]-48)*16 + (Rx_time[4]-48);
	 DateToUpdate.Year = (Rx_time[6]-48)*16 + (Rx_time[7]-48);

	 if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BCD) != HAL_OK)
	 {
		 Error_Handler();
	 }
}

void strToInt(uint32_t* waitTime,uint8_t* Rx_data_delay, size_t numBytes)
{
	int i;
	/*TODO reset waitTime to 0 each time*/
	for(i=0;i<numBytes;i++)
	{
		if((Rx_data_delay[i] >= 48) && (Rx_data_delay[i] <= 57) )
		{
			*waitTime = *waitTime + (Rx_data_delay[i]-48)* pow(10,numBytes-i-1);
		}
		else
		{
			myprintf("Wrong input try again!\r\n");
		}
	}
}

uint8_t Rx_data_resitorVal[5] = "02000";
uint8_t Rx_data_RTCtime[14] = "31.12.99 23:59";
uint8_t Rx_data_delay[6] = "002000";


void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if( !HAL_GPIO_ReadPin(enterResistorVal_GPIO_Port, enterResistorVal_Pin) )
	{
		HAL_UART_Receive_IT(&huart3, Rx_data_resitorVal, 5); //restart the interrupt reception mode
	}
	else if( !HAL_GPIO_ReadPin(enterRTCtime_GPIO_Port, enterRTCtime_Pin) )
	{
		HAL_UART_Receive_IT(&huart3, Rx_data_RTCtime, 14);
	}
	else if( !HAL_GPIO_ReadPin(enterDelay_GPIO_Port, enterDelay_Pin) )
	{
		HAL_UART_Receive_IT(&huart3, Rx_data_delay, 6);
	}
	else
	{
		myprintf("Error RcCpltCallbak or DIP pins in undefined state!\r\n");
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */


  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART3_UART_Init();
  MX_ADC1_Init();
  MX_SPI2_Init();
  MX_FATFS_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

  myprintf("\r\n~ Bio cell meter start... ~\r\n\r\n");

  HAL_Delay(1000);

  FATFS FatFs;
  FIL fil;
  FRESULT fres;
  FILINFO fno;
  UINT bytesWrote;

  //Open the file system
  fres = f_mount(&FatFs, "",1); //1=mount now
  if (fres != FR_OK)
  {
	  myprintf("f_mount error (%i)\r\n", fres);
	  while(1);
  }
  else
  {
	  myprintf("SD mounted successfully!\r\n");
  }

   //Let's get some statistics from the SD card
   DWORD free_clusters, free_sectors, total_sectors;

   FATFS* getFreeFs;

   fres = f_getfree("", &free_clusters, &getFreeFs);
   if (fres != FR_OK)
   {
	   myprintf("f_getfree error (%i)\r\n", fres);
	   while(1);
   }
   else
   {
	   myprintf("Successfully read SD stats!\r\n");
   }

   //Formula comes from ChaN's documentation
   total_sectors = (getFreeFs->n_fatent - 2) * getFreeFs->csize;
   free_sectors = free_clusters * getFreeFs->csize;

   myprintf("SD card stats:\r\n%10lu KiB total drive space.\r\n%10lu KiB available.\r\n", total_sectors / 2, free_sectors / 2);

   //Now lets test open 10 files to write to"
   /*set names for 10 different files*/
   const TCHAR fPath[10][10] = { "CELL0.TXT\0","CELL1.TXT\0","CELL2.TXT\0","CELL3.TXT\0","CELL4.TXT\0","CELL5.TXT\0","CELL6.TXT\0","CELL7.TXT\0","CELL8.TXT\0","CELL9.TXT\0"};
   int i=0;
   char readBuff[65] = "Measurements in format: Voltage[mV], Current[uA], Power[uW]\r\n";

   /*open 10 files to check*/
   for(i=0; i<10; i++)
   {
	   myprintf("File %d name %s\r\n",i,fPath[i]);
	   //HAL_Delay(2000);
	   fres = f_stat(fPath[i], &fno);
	   switch(fres)
	   {
	   case FR_OK:
		   myprintf("File CELL%d is existent...closing file\r\n",i);
		   break;
	   case FR_NO_FILE:
		   myprintf("File CELL%d is non existent...opening file\r\n",i);
		   fres = f_open(&fil, fPath[i], FA_WRITE | FA_OPEN_ALWAYS);
		   if(fres == FR_OK)
		   {
			   fres = f_write(&fil, readBuff , strlen(readBuff), &bytesWrote);
			   if(fres == FR_OK)
			   {
				   myprintf("I was able to open 'CELL%d.txt' for writing\r\n",i);
				   myprintf("Wrote %i bytes to 'CELL%d.txt'! ...closing file\r\n", bytesWrote,i);
				   f_close(&fil);
			   }
		   }
		   else
		   {
			   myprintf("f_write error (%i)\r\n");
		   }
		   break;
	   default:
		   myprintf("f_stat error (%i)\r\n",fres);
	   }
   }

   //f_close(&fil); //if file is not closed after writing on it data is not saved



   char VCP_str[80];
   HAL_StatusTypeDef ret;
   float resistorVal = 2000;
   float voltageVal = 0;
   float loadCurrent = 0;
   float loadPower = 0;
   uint32_t waitTime = 2000; //time to wait in delay

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
   /*read resistor value from uart*/

  //while(1);/*hold the program in loop for testing*/

  while(1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  /*update the resistorVal during runtime, if pin B9 is LOW input is enabled*/
	  while( !HAL_GPIO_ReadPin(enterResistorVal_GPIO_Port, enterResistorVal_Pin) )//not to get TRUE => PULLUP on pin
	  {
		  myprintf("Input the value of the resistance in ohms etc.  09864 = 9864 ohm \r\n");
		  HAL_UART_Receive_IT(&huart3, Rx_data_resitorVal, 5);
		  uintToFloat(&resistorVal, Rx_data_resitorVal, strlen((char*)Rx_data_resitorVal));
		  myprintf("Rx_data = %s, resistorVal = %f \r\n", Rx_data_resitorVal,resistorVal);
		  HAL_Delay(5000);
	  }

	  /*set/reset RTC initial time during runtime, if pin B8 is LOW input is enabled */
	  while( !HAL_GPIO_ReadPin(enterRTCtime_GPIO_Port, enterRTCtime_Pin) )
	  {
		  myprintf("Input the RTC initial value in format: xx.xx.xx xx:xx\r\n");
		  HAL_UART_Receive_IT(&huart3, Rx_data_RTCtime, 14);
		  setDateTime(Rx_data_RTCtime, strlen((char*)Rx_data_RTCtime));
		  myprintf("Rx_RTC_time = %s\r\n",Rx_data_RTCtime);
		  HAL_Delay(5000);
	  }

	  /*update value of delay for sampling*/
	  while( !HAL_GPIO_ReadPin(enterDelay_GPIO_Port, enterDelay_Pin) )
	  {
		  myprintf("Input the delay time im milisec (format xxxxxx) etc. 000002 = 2ms\r\n");
		  HAL_UART_Receive_IT(&huart3,Rx_data_delay, 6);
		  strToInt(&waitTime, Rx_data_delay, strlen((char*)Rx_data_delay));
		  myprintf("Rx_data_delay = %s, delay = %d\n\r",Rx_data_delay, waitTime);
		  HAL_Delay(5000);
	  }

	  /*dismount SD during runtime*/
	  while( !HAL_GPIO_ReadPin(SDdismount_GPIO_Port, SDdismount_Pin))
	  {
		  USER_FATFS_DeInit();

		  HAL_Delay(5000);
		  fres = f_mount(0, "", 0);
		  if(fres != FR_OK)
		  {
			  myprintf("Unmount error (%i)\r\n", fres);
		  }
		  else
		  {
			  myprintf("Unmounted successfully, SD card can be removed now! \r\n");
		  }
	  }

	  while( !HAL_GPIO_ReadPin(SDmount_GPIO_Port, SDmount_Pin) )
	  {
		  HAL_Delay(5000);
		  USER_FATFS_DeInit();
		  myprintf("SD can be inserted now! \r\n");

		  if(!HAL_GPIO_ReadPin(SDmount_GPIO_Port, SDmount_Pin))
		  {
			  MX_FATFS_Init();
			  fres = f_mount(&FatFs, "",1); //1= mount now/0= delayed mount
			  if (fres != FR_OK)
			  {
				  myprintf("f_mount error (%i)\r\n", fres);
			  }
			  else
			  {
				  myprintf("SD mounted successfully! \r\n");
			  }
		  }
	  }

	  /*open file to write*/
//	  fres = f_open(&fil, "write.txt", FA_WRITE | FA_OPEN_ALWAYS );
//	  if(fres == FR_OK)
//	  {
//		  fres = f_lseek(&fil, f_size(&fil));
//		  if(fres != FR_OK)
//		  {
//			  myprintf("f_lseek() error (%i)", fres);
//		  }
//		  else
//		  {
//			  myprintf("I was able to open 'write.txt' for writing in append mode\r\n");
//		  }
//
//	  }
//	  else
//	  {
//		  myprintf("Could not open the file, error (%i) \r\n", fres);
//	  }

	  /*Calibrate the ADC since sampling is done after every 10 min*/

	  ret = HAL_ADCEx_Calibration_Start(&hadc1);
	  if(ret != HAL_OK)
	  {
		  Error_Handler();
		  myprintf("ADC calibration error\r\n");
	  }

	  /*Read analog values from all 10 channels*/
	  ADC_Select_CH0();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[0] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH1();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[1] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH2();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[2] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH3();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[3] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH4();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[4] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH5();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[5] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH6();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[6] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH7();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[7] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH8();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[8] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  ADC_Select_CH9();
	  HAL_ADC_Start(&hadc1);
	  HAL_ADC_PollForConversion(&hadc1, 20);
	  AD_RES[9] = HAL_ADC_GetValue(&hadc1);
	  HAL_ADC_Stop(&hadc1);

	  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
	  HAL_RTC_GetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BIN);

	  /*Write analog values to a file and print on serial*/
	  for(i=0;i<10;i++)
	  {
		  /*open files one bz one in a loop to write to them and close*/

		   fres = f_open(&fil, fPath[i], FA_WRITE | FA_OPEN_ALWAYS);
		   if(fres == FR_OK)
		   {
			   fres = f_lseek(&fil, f_size(&fil));
			   if(fres != FR_OK)
			   {
				   myprintf("f_lseek() error (%i)\r\n", fres);
			   }
			   else
			   {
				   myprintf("Successfully opened file CELL%d, ", i);
			   }
		   }
		   else
		   {
			   myprintf("f_open error (%i)\r\n", fres);
		   }

		  voltageVal = (float)AD_RES[i]/(float)4095*3300.0; //[mV] calculate the voltage value from AD_RES
		  loadCurrent = (voltageVal/resistorVal)*1000;//[uA] calculation of load current, divison of 2 floats results in float
		  loadPower = (voltageVal * voltageVal)/ resistorVal;//[uW]	calculation of power

		  sprintf(VCP_str, "CELL%d,%.2d.%.2d.%.2d,%.2d:%.2d,%.2f,%.2f,%.2f\r\n",i,
				  DateToUpdate.Date, DateToUpdate.Month, DateToUpdate.Year+2000 ,
				  sTime.Hours, sTime.Minutes,
				  voltageVal, loadCurrent, loadPower );
		  fres = f_write(&fil, VCP_str, strlen(VCP_str), &bytesWrote);
		  if(fres == FR_OK)
		  {
			  myprintf("wrote %i bytes to 'write.txt'!\r\n", bytesWrote);
		  }
		  else
		  {
			  myprintf("f_write error (%i)\r\n", fres);
		  }
		  myprintf("%s\r\n",VCP_str);
		  f_close(&fil); //if file is not closed after writing on it data is not saved
	  }
	  // might need to remove this toggle
	  HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
	  HAL_Delay(waitTime);
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI|RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV2;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief ADC1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.NbrOfConversion = 1;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_239CYCLES_5;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  //RTC_TimeTypeDef sTime = {0};
  //RTC_DateTypeDef DateToUpdate = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.AsynchPrediv = RTC_AUTO_1_SECOND;
  hrtc.Init.OutPut = RTC_OUTPUTSOURCE_ALARM;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
//  sTime.Hours = 0x1;
//  sTime.Minutes = 0x1;
//  sTime.Seconds = 0x1;

  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  DateToUpdate.WeekDay = RTC_WEEKDAY_MONDAY;
  DateToUpdate.Month = RTC_MONTH_JANUARY;
//  DateToUpdate.Date = 0x1;
//  DateToUpdate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &DateToUpdate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_128;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 38400;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SD_CS_GPIO_Port, SD_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : SD_CS_Pin */
  GPIO_InitStruct.Pin = SD_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(SD_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SDmount_Pin */
  GPIO_InitStruct.Pin = SDmount_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(SDmount_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SDdismount_Pin enterDelay_Pin enterRTCtime_Pin enterResistorVal_Pin */
  GPIO_InitStruct.Pin = SDdismount_Pin|enterDelay_Pin|enterRTCtime_Pin|enterResistorVal_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
